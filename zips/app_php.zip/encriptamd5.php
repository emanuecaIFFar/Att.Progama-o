<?php
$senha = "123456";
$senha_encriptada = md5($senha);

echo $senha_encriptada;
?>